//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDR_SHELLCODE32                 101
#define IDR_SHELLCODE64                 102
#define IDR_WORDLIST                    104
#define IDR_APLIB32                     105
#define IDR_APLIB64                     106
#define IDR_RESTORE_SHELLCODE           107
#define IDR_RCDATA1                     109
#define IDR_STUB_SYMBOLS                109

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
