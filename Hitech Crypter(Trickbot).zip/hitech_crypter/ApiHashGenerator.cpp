#include <windows.h>
#include "mCode.h"
#include "mPathBuilder.h"
#include "ApiHashGenerator.h"

#include <basetsd.h>
#include <unordered_map>
#include <string>

const static std::unordered_map<std::string, int> gHashApiMap = {
	//kernel32.dll
	{ "LoadLibraryA", 1 },
	{ "LoadLibraryW", 1 },
	{ "LoadLibraryExA", 1 },
	{ "LoadLibraryExW", 1 },
	{ "FreeLibrary", 1 },
	{ "GetProcAddress", 1 },
	{ "TerminateProcess", 1 },
	{ "VirtualAlloc", 1 },
	{ "VirtualAllocEx", 1 },
	{ "VirtualFree", 1 },
	{ "VirtualFreeEx", 1 },
	{ "VirtualQuery", 1 },
	{ "VirtualQueryEx", 1 },
	{ "VirtualProtect", 1 },
	{ "VirtualProtectEx", 1 },
	{ "CloseHandle", 1 },
	{ "GlobalAlloc", 1 },
	{ "GlobalFree", 1 },
	{ "CreateFileA", 1 },
	{ "CreateFileW", 1 },
	{ "WriteFile", 1 },
	{ "GetCurrentDirectoryA", 1 },
	{ "WriteProcessMemory", 1 },
	{ "CreateRemoteThread", 1 },
	{ "ReadFile", 1 },
	{ "SetFilePointer", 1 },
	{ "CopyFileA", 1 },
	{ "CopyFileW", 1 },
	{ "MoveFileA", 1 },
	{ "MoveFileW", 1 },
	{ "MoveFileExA", 1 },
	{ "MoveFileExW", 1 },
	{ "DeleteFileA", 1 },
	{ "DeleteFileW", 1 },
	{ "GetFileSize", 1 },
	{ "CreateFileMappingA", 1 },
	{ "CreateFileMappingW", 1 },
	{ "MapViewOfFile", 1 },
	{ "GetFileTime", 1 },
	{ "SetFileTime", 1 },
	{ "GetModuleHandleA", 1 },
	{ "GetModuleHandleW", 1 },
	{ "UnmapViewOfFile", 1 },
	{ "WaitForSingleObject", 1 },
	{ "Sleep", 1 },
	{ "WideCharToMultiByte", 1 },
	{ "MultiByteToWideChar", 1 },
	{ "GetModuleFileNameA", 1 },
	{ "GetModuleFileNameW", 1 },
	{ "GetSystemDirectoryA", 1 },
	{ "GetSystemDirectoryW", 1 },
	{ "GetTempPathA", 1 },
	{ "GetTempPathW", 1 },
	{ "GetVolumeInformationA", 1 },
	{ "GetVolumeInformationW", 1 },
	{ "SetFileAttributesA", 1 },
	{ "SetFileAttributesW", 1 },
	{ "CreateProcessA", 1 },
	{ "CreateProcessW", 1 },
	{ "GetVersionExA", 1 },
	{ "GetVersionExW", 1 },
	{ "CreateThread", 1 },
	{ "CreateMutexA", 1 },
	{ "CreateMutexW", 1 },
	{ "ReleaseMutex", 1 },
	{ "GetVersion", 1 },
	{ "DeviceIoControl", 1 },
	{ "QueryDosDeviceA", 1 },
	{ "QueryDosDeviceW", 1 },
	{ "IsBadReadPtr", 1 },
	{ "IsBadWritePtr", 1 },
	{ "GetCurrentProcess", 1 },
	{ "CreateMutexA", 1 },
	{ "CreateMutexW", 1 },
	{ "ReleaseMutex", 1 },
	{ "CreateEventW", 1 },
	{ "SetEvent", 1 },
	{ "ResetEvent", 1 },
	{ "GetShortPathNameA", 1 },
	{ "GetShortPathNameW", 1 },
	{ "LocalFree", 1 },
	{ "GetPrivateProfileStringA", 1 },
	{ "GetPrivateProfileStringW", 1 },
	{ "GetFileAttributesA", 1 },
	{ "GetFileAttributesW", 1 },
	{ "GetEnvironmentVariableA", 1 },
	{ "GetEnvironmentVariableW", 1 },
	{ "ReadProcessMemory", 1 },
	{ "ExitProcess", 1 },
	{ "OpenProcess", 1 },
	{ "GetCurrentProcessId", 1 },
	{ "Process32First", 1 },
	{ "Process32Next", 1 },
	{ "CreateToolhelp32Snapshot", 1 },
	{ "WinExec", 1 },
	{ "FindResourceA", 1 },
	{ "SetLastError", 1 },
	{ "LoadResource", 1 },
	{ "LockResource", 1 },
	{ "SizeofResource", 1 },
	{ "LockRsrc", 1 },
	{ "GetTempFileNameA", 1 },
	{ "GetTempFileNameW", 1 },
	{ "GetLongPathNameA", 1 },
	{ "CreateEventA", 1 },
	{ "ConnectNamedPipe", 1 },
	{ "CreateNamedPipeA", 1 },
	{ "GetTickCount", 1 },
	{ "ExitThread", 1 },
	{ "lstrcmpiA", 1 },
	{ "SuspendThread", 1 },
	{ "GetComputerNameA", 1 },
	{ "GetThreadContext", 1 },
	{ "SetThreadContext", 1 },
	{ "ResumeThread", 1 },
	{ "ProcessIdToSessionId", 1 },
	{ "WTSGetActiveConsoleSessionId", 1 },
	{ "OpenMutexA", 1 },
	{ "CreateProcessInternalA", 1 },
	{ "CreateProcessInternalW", 1 },
	{ "TerminateThread", 1 },
	{ "lopen", 1 },
	{ "lstrcmpA", 1 },
	{ "lstrcmpW", 1 },
	{ "lstrcatA", 1 },
	{ "lstrcatW", 1 },
	{ "lstrcpyA", 1 },
	{ "lstrcpyW", 1 },
	{ "lstrlenA", 1 },
	{ "lstrlenW", 1 },
	{ "Thread32First", 1 },
	{ "Thread32Next", 1 },
	{ "OpenThread", 1 },
	{ "GetWindowsDirectoryA", 1 },
	{ "GetWindowsDirectoryW", 1 },
	{ "FindFirstFileA", 1 },
	{ "FindNextFileA", 1 },
	{ "FindClose", 1 },
	{ "GetProcessHeap", 1 },
	{ "InitializeCriticalSection", 1},
	{ "EnterCriticalSection", 1 },
	{ "LeaveCriticalSection", 1 },
	{ "DeleteCriticalSection", 1 },

	//advapi32.dll
	{ "CreateProcessAsUserA", 2 },
	{ "SetThreadToken", 2 },
	{ "OpenProcessToken", 2 },
	{ "LookupPrivilegeValueA", 2 },
	{ "LookupPrivilegeValueW", 2 },
	{ "AdjustTokenPrivileges", 2 },
	{ "RegOpenKeyExA", 2 },
	{ "RegOpenKeyExW", 2 },
	{ "RegQueryInfoKeyA", 2 },
	{ "RegQueryInfoKeyW", 2 },
	{ "RegEnumKeyExA", 2 },
	{ "RegEnumKeyExW", 2 },
	{ "RegEnumValueA", 2 },
	{ "RegEnumValueW", 2 },
	{ "RegQueryValueExA", 2 },
	{ "RegQueryValueExW", 2 },
	{ "RegCloseKey", 2 },
	{ "RegDeleteKeyA", 2 },
	{ "RegDeleteKeyW", 2 },
	{ "RegSetValueExA", 2 },
	{ "RegSetValueExW", 2 },
	{ "GetUserNameA", 2 },
	{ "GetUserNameW", 2 },
	{ "OpenServiceA", 2 },
	{ "StartServiceA", 2 },
	{ "GetKernelObjectSecurity", 2 },
	{ "OpenSCManagerA", 2 },
	{ "GetCurrentHwProfileA", 2 },
	{ "GetTokenInformation", 2 },
	{ "InitializeSecurityDescriptor", 2 },
	{ "SetSecurityDescriptorOwner", 2 },
	{ "SetFileSecurityW", 2 },
	{ "LookupAccountSidA", 2},
	{ "ConvertSidToStringSidA", 2},

	//user32.dll
	{ "ExitWindowsEx", 3 },
	{ "MessageBoxA", 3 },
	{ "PeekMessageW", 3 },
	{ "DispatchMessageW", 3 },
	{ "MsgWaitForMultipleObjects", 3 },
	{ "WaitForInputIdle", 3 },
	{ "GetWindowThreadProcessId", 3 },
	{ "FindWindowA", 3 },
	{ "GetSystemMetrics", 3 },
	{ "GetActiveWindow", 3 },
	{ "GetKeyboardLayoutNameA", 3 },
	{ "OpenClipboard", 3 },
	{ "GetClipboardData", 3 },
	{ "CloseClipboard", 3 },
	{ "GetWindowTextA", 3 },
	{ "GetForegroundWindow", 3 },
	{ "GetWindowLongPtrA", 3 },
	{ "GetWindowLongPtrW", 3 },
	{ "EnumChildWindows", 3 },
	{ "GetParent", 3 },
	{ "GetDesktopWindow", 3 },
	{ "IsWindowVisible", 3 },
	{ "SetWindowLongA", 3 },
	{ "GetWindowLongA", 3 },
	{ "SetLayeredWindowAttributes", 3 },
	{ "SetWindowPos", 3 },

	//ntdll.dll
	{ "RtlInitUnicodeString", 5 },
	{ "RtlInitAnsiString", 5 },
	{ "NtOpenFile", 5 },
	{ "NtOpenDirectoryObject", 5 },
	{ "NtCreateSection", 5 },
	{ "NtOpenSection", 5 },
	{ "ZwLoadDriver", 5 },
	{ "ZwUnloadDriver", 5 },
	{ "RtlAdjustPrivilege", 5 },
	{ "ZwMakeTemporaryObject", 5 },
	{ "NtClose", 5 },
	{ "RtlImageNtHeader", 5 },
	{ "ZwQuerySystemInformation", 5 },
	{ "ZwUnmapViewOfSection", 5 },
	{ "ZwMapViewOfSection", 5 },
	{ "ZwQueueApcThread", 5 },
	{ "ZwResumeThread", 5 },
	{ "ZwTestAlert", 5 },
	{ "ZwQueryInformationThread", 5 },
	{ "ZwOpenProcess", 5 },
	{ "ZwOpenProcessToken", 5 },
	{ "ZwClose", 5 },
	{ "ZwAllocateVirtualMemory", 5 },
	{ "ZwFreeVirtualMemory", 5 },
	{ "ZwWriteVirtualMemory", 5 },
	{ "ZwProtectVirtualMemory", 5 },
	{ "RtlCreateUserThread", 5 },
	{ "LdrLoadDll", 5 },
	{ "LdrGetDllHandle", 5 },
	{ "LdrGetProcedureAddress", 5 },
	{ "ZwSetContextThread", 5 },
	{ "ZwSetInformationProcess", 5 },
	{ "ZwQueryInformationProcess", 5},
	{ "RtlAllocateHeap", 5 },
	{ "RtlCompareMemory", 5},
};

DWORD64 apiCalcHash(LPCSTR _str, DWORD64 _hash)
{
	if (!_str)
		return -1;

	while (*_str) {
		_hash = ((_hash << 7) & (DWORD)(-1)) | (_hash >> (32 - 7));
		_hash = _hash ^ (*_str);
		_str++;
	}

	return _hash;
}

DWORD64 apiCalcHashW(LPCWSTR _str, DWORD64 _hash)
{
	if (!_str)
		return 0;

	while (*_str) {
		_hash = ((_hash << 7) & (DWORD)-1) | (_hash >> (32 - 7));
		_hash = _hash ^ *_str;
		_str++;
	}

	return _hash;
}

void makeApiHash(DWORD64 _seed, mPathBuilder _path)
{
	mCode source(0xFFFF);
	mCode header(0xFFFF);

	header.clear();
	header << "#if !defined(GET_API_H)\r\n"
		"#define GET_API_H\r\n\r\n"

		"LPVOID getApiAddr(HMODULE _module, DWORD64 _procNameHash);\r\n"
		"LPVOID getProcAddressEx(LPCSTR _dll, DWORD _moduleNumber, DWORD64 _hash);\r\n\r\n"
	
		"template <DWORD _moduleNumber, DWORD64 _procNameHash>\r\n"
		"inline LPVOID pushargEx()\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)();\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func();\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A>\r\n"
		"inline LPVOID pushargEx(A a1)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B>\r\n"
		"inline LPVOID pushargEx(A a1, B a2)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G, class H>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7, H a8)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G, H);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7, a8);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G, class H, class I>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7, H a8, I a9)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G, H, I);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7, a8, a9);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G, class H, class I, class X>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7, H a8, I a9, X a10)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G, H, I, X);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G, class H, class I, class X, class Y>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7, H a8, I a9, X a10, Y a11)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G, H, I, X, Y);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11);\r\n"
		"}\r\n"
		"\r\n"
		"template <DWORD _moduleNumber, DWORD64 _procNameHash, class A, class B, class C, class D, class E, class F, class G, class H, class I, class X, class Y, class Z, class R>\r\n"
		"inline LPVOID pushargEx(A a1, B a2, C a3, D a4, E a5, F a6, G a7, H a8, I a9, X a10, Y a11, Z a12, R a13)\r\n"
		"{\r\n"
		"	typedef LPVOID(WINAPI* newfunc)(A, B, C, D, E, F, G, H, I, X, Y, Z, R);\r\n"
		"	newfunc func = (newfunc)getProcAddressEx(NULL, _moduleNumber, _procNameHash);\r\n"
		"	return func(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13);\r\n"
		"}\r\n\r\n"
		"#endif\r\n";


	for (auto i = gHashApiMap.begin(); i != gHashApiMap.end(); ++i) {
		header << "#define p" << i->first.data() << " pushargEx<" << i->second << ", " << apiCalcHash(i->first.data(), _seed) << ">\r\n";
	}

	char _headerFile[MAX_PATH] = {};

	lstrcpyA(_headerFile, _path.get_tmp_folder());
	lstrcatA(_headerFile, "GetApi.h");

	file_put_contentsA(_headerFile, header.get(), header.length());

	source << 
		"#include \"symbols.h\"\r\n"
		"#include \"GetApi.h\"\r\n"
		"\r\n"
 		"#define HASH_CACHE_MAX_SIZE " << gHashApiMap.size() <<"\r\n"
 		"DWORD64 gHashCacheKey[HASH_CACHE_MAX_SIZE];\r\n"
 		"LPVOID gHashCacheValue[HASH_CACHE_MAX_SIZE];\r\n"
		"DWORD gHashCacheSize = 0;\r\n"
		"\r\n"
		"LPVOID findHashCache(DWORD64 _procNameHash)\r\n"
		"{\r\n"
		"	if (gHashCacheSize == 0)\r\n"
		"		return 0;\r\n"
		"\r\n"
		"	for (int i = 0; i < gHashCacheSize; i++) {\r\n"
		"		if (gHashCacheKey[i] == _procNameHash)\r\n"
		"			return gHashCacheValue[i];\r\n"
		"	}\r\n"
		"\r\n"
		"	return 0;\r\n"
		"}\r\n"
		"\r\n"
		"void insertToCache(DWORD64 _procNameHash, LPVOID _api)\r\n"
		"{\r\n"
		"	gHashCacheKey[gHashCacheSize] = _procNameHash;\r\n"
		"	gHashCacheValue[gHashCacheSize ++] = _api;\r\n"
		"}\r\n"
		"\r\n"
		"DWORD64 calcHashW(LPCWSTR _str)\r\n"
		"{\r\n"
		"	if (!_str)\r\n"
		"		return 0;\r\n"
		"\r\n"
		"	DWORD64 _hash = " << _seed << ";\r\n"
		"\r\n"
		"	while (*_str) {\r\n"
		"		_hash = ((_hash << 7) & (DWORD)-1) | (_hash >> (32 - 7));\r\n"
		"		_hash = _hash ^ *_str;\r\n"
		"		_str++;\r\n"
		"	}\r\n"
		"\r\n"
		"	return _hash;\r\n"
		"}\r\n"
		"\r\n"
		"DWORD64 calcHash(LPCSTR _str)\r\n"
		"{\r\n"
		"	if (!_str)\r\n"
		"		return -1;\r\n"
		"\r\n"
		"	DWORD64 _hash = " << _seed << ";\r\n"
		"\r\n"
		"	while (*_str) {\r\n"
		"		_hash = ((_hash << 7) & (DWORD)(-1)) | (_hash >> (32 - 7));\r\n"
		"		_hash = _hash ^ (*_str);\r\n"
		"		_str++;\r\n"
		"	}\r\n"
		"\r\n"
		"	return _hash;\r\n"
		"}\r\n"
		"\r\n"
		"HMODULE getKernel32()\r\n"
		"{\r\n"
		"	auto _ldrData = NtCurrentPeb()->Ldr;\r\n"
		"	auto _head = &_ldrData->InLoadOrderModuleList;\r\n"
		"	auto _entry = _head->Flink;\r\n"
		"\r\n"
		"	while (_entry != _head) {\r\n"
		"		auto _ldr = CONTAINING_RECORD(_entry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);\r\n"
		"\r\n"
		"		WCHAR _dllName[MAX_PATH] = {};\r\n"
		"		mem_set(_dllName, 0, sizeof(_dllName));\r\n"
		"\r\n"
		"		StrCpyNW(_dllName, _ldr->BaseDllName.Buffer, min(MAX_PATH - 1, _ldr->BaseDllName.Length / sizeof(WCHAR) + 1));\r\n"
		"\r\n"
		"		if (calcHashW(CharLowerW(_dllName)) == " << apiCalcHashW(L"kernel32.dll", _seed) << ")\r\n"
		"			return (HMODULE)_ldr->DllBase;\r\n"
		"\r\n"
		"		_entry = _entry->Flink;\r\n"
		"	}\r\n"
		"\r\n"
		"	return 0;\r\n"
		"}\r\n"
		"\r\n"
		"LPVOID getApiAddr(HMODULE _module, DWORD64 _procNameHash)\r\n"
		"{\r\n"
		"	auto _cached = findHashCache(_procNameHash);\r\n"
		"\r\n"
		"	if (_cached != 0)\r\n"
		"		return _cached;\r\n"
		"\r\n"
		"	auto _dosHeader = (PIMAGE_DOS_HEADER)_module;\r\n"
		"\r\n"
		"	if (_dosHeader->e_magic != IMAGE_DOS_SIGNATURE)\r\n"
		"		return 0;\r\n"
		"\r\n"
		"	auto _ntHeader = (PIMAGE_NT_HEADERS)PTR_ADD_OFFSET(_module, _dosHeader->e_lfanew);\r\n"
		"\r\n"
		"	if (_ntHeader->Signature != IMAGE_NT_SIGNATURE)\r\n"
		"		return 0;\r\n"
		"\r\n"
		"	auto _optionalHeader = (PIMAGE_OPTIONAL_HEADER)&_ntHeader->OptionalHeader;\r\n"
		"	auto _exportDir = (PIMAGE_EXPORT_DIRECTORY)PTR_ADD_OFFSET(_module, _optionalHeader->DataDirectory[0].VirtualAddress);\r\n"
		"\r\n"
		"	int _ordinal = 0;\r\n"
		"\r\n"
		"	auto _names = (DWORD*)PTR_ADD_OFFSET(_module, _exportDir->AddressOfNames);\r\n"
		"	auto _ordinals = (WORD*)PTR_ADD_OFFSET(_module, _exportDir->AddressOfNameOrdinals);\r\n"
		"\r\n"
		"	auto i = 0;\r\n"
		"\r\n"
		"	for (i = 0; i < _exportDir->NumberOfNames; i++, _names++, _ordinals++) {\r\n"
		"		LPCSTR _apiName = (const char*)PTR_ADD_OFFSET(_module, *_names);\r\n"
		"\r\n"
		"		if (calcHash(_apiName) == _procNameHash) {\r\n"
		"			_ordinal = *_ordinals;\r\n"
		"			break;\r\n"
		"		}\r\n"
		"	}\r\n"
		"\r\n"
		"	if (i == _exportDir->NumberOfNames)\r\n"
		"		return 0;\r\n"
		"\r\n"
		"	auto _addrTable = (PDWORD)PTR_ADD_OFFSET(_module, _exportDir->AddressOfFunctions);\r\n"
		"	auto _rvaAddr = _addrTable[_ordinal];\r\n"
		"	auto _ret = PTR_ADD_OFFSET(_module, _rvaAddr);\r\n"
		"\r\n"
		"	insertToCache(_procNameHash, _ret);\r\n"
		"\r\n"
		"	return _ret;\r\n"
		"}\r\n"
		"\r\n"
		"LPVOID getProcAddressEx(LPCSTR _dll, DWORD _moduleNumber, DWORD64 _procNameHash)\r\n"
		"{\r\n"
		"	HMODULE _module = NULL;\r\n"
		"\r\n"
		"	char kernel32_dll[] = { 'k','e','r','n','e','l','3','2','.','d','l','l',0 };\r\n"
		"	char advapi32_dll[] = { 'a','d','v','a','p','i','3','2','.','d','l','l',0 };\r\n"
		"	char user32_dll[] = { 'u','s','e','r','3','2','.','d','l','l',0 };\r\n"
		"	char ws2_32_dll[] = { 'w','s','2','_','3','2','.','d','l','l',0 };\r\n"
		"	char ntdll_dll[] = { 'n','t','d','l','l','.','d','l','l',0 };\r\n"
		"	char winsta_dll[] = { 'w','i','n','s','t','a','.','d','l','l',0 };\r\n"
		"	char shell32_dll[] = { 's','h','e','l','l','3','2','.','d','l','l',0 };\r\n"
		"	char wininet_dll[] = { 'w','i','n','i','n','e','t','.','d','l','l',0 };\r\n"
		"	char urlmon_dll[] = { 'u','r','l','m','o','n','.','d','l','l',0 };\r\n"
		"	char nspr4_dll[] = { 'n','s','p','r','4','.','d','l','l',0 };\r\n"
		"	char ssl3_dll[] = { 's','s','l','3','.','d','l','l',0 };\r\n"
		"\r\n"
		"	LPSTR _dllName = NULL;\r\n"
		"\r\n"
		"	if (_dll == NULL)\r\n"
		"	{\r\n"
		"		switch (_moduleNumber)\r\n"
		"		{\r\n"
		"		case 1:\r\n"
		"			_module = getKernel32();\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 2:\r\n"
		"			_dllName = advapi32_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 3:\r\n"
		"			_dllName = user32_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 4:\r\n"
		"			_dllName = ws2_32_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 5:\r\n"
		"			_dllName = ntdll_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 6:\r\n"
		"			_dllName = winsta_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 7:\r\n"
		"			_dllName = shell32_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 8:\r\n"
		"			_dllName = wininet_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 9:\r\n"
		"			_dllName = urlmon_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 10:\r\n"
		"			_dllName = nspr4_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		case 11:\r\n"
		"			_dllName = ssl3_dll;\r\n"
		"			break;\r\n"
		"\r\n"
		"		default:\r\n"
		"			return 0;\r\n"
		"		}\r\n"
		"	} else {\r\n"
		"		_module = (HMODULE)pLoadLibraryA(_dll);\r\n"
		"	}\r\n"
		"\r\n"
		"	if (_module == nullptr && lstrlenA(_dllName))\r\n"
		"	{\r\n"
		"		_module = (HMODULE)pLoadLibraryA(_dllName);\r\n"
		"	}\r\n"
		"\r\n"
		"	LPVOID ret = getApiAddr(_module, _procNameHash);\r\n"
		"\r\n"
		"	return ret;\r\n"
		"}\r\n";

	char _sourceFile[MAX_PATH] = {};

	lstrcpyA(_sourceFile, _path.get_tmp_folder());
	lstrcatA(_sourceFile, "GetApi.cpp");

	file_put_contentsA(_sourceFile, source.get(), source.length());
}