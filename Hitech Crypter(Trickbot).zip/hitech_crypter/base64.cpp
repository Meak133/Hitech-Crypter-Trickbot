#include <windows.h>
#include "base64.h"
#include "funcs.h"

//Lookup table for encoding
//If you want to use an alternate alphabet, change the characters here
CHAR encodeLookup[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
CHAR padCharacter = '=';

PCHAR base64_encode(PBYTE data, DWORD data_size)
{
	PCHAR encodedString = (PCHAR)halloc((((data_size/3) + (data_size % 3 > 0)) * 4 + 1)* sizeof(CHAR));
	PCHAR current = encodedString;

	if( !current )
		return NULL;

	DWORD temp;
	for(size_t idx = 0; idx < data_size/3; idx++)
	{
		temp  = (*data++) << 16; //Convert to big endian
		temp += (*data++) << 8;
		temp += (*data++);

		*current++ = encodeLookup[(temp & 0x00FC0000) >> 18];
		*current++ = encodeLookup[(temp & 0x0003F000) >> 12];
		*current++ = encodeLookup[(temp & 0x00000FC0) >> 6 ];
		*current++ = encodeLookup[(temp & 0x0000003F)      ];
	}

	switch(data_size % 3)
	{
		case 1:
			temp  = (*data++) << 16; //Convert to big endian

			*current++ = encodeLookup[(temp & 0x00FC0000) >> 18];
			*current++ = encodeLookup[(temp & 0x0003F000) >> 12];
			*current++ = padCharacter;
			*current++ = padCharacter;
			break;
		case 2:
			temp  = (*data++) << 16; //Convert to big endian
			temp += (*data++) << 8;

			*current++ = encodeLookup[(temp & 0x00FC0000) >> 18];
			*current++ = encodeLookup[(temp & 0x0003F000) >> 12];
			*current++ = encodeLookup[(temp & 0x00000FC0) >> 6 ];
			*current++ = padCharacter;
			break;
	}

	*current++ = 0;

	return encodedString;
}

PBYTE base64_decode(PCHAR input, DWORD input_length)
{
	if (input_length % 4) //Sanity check
		return NULL;

	DWORD padding = 0;

	if (input_length)
	{
		if (input[input_length-1] == padCharacter)
			padding++;
		if (input[input_length-2] == padCharacter)
			padding++;
	}
	//Setup a vector to hold the result
	PBYTE decodedBytes = (PBYTE)halloc(((input_length/4)*3) - padding );
	PBYTE posdec = decodedBytes;

	DWORD temp=0; //Holds decoded quanta
	PCHAR cursor = input;
	PCHAR cursor_end = input + input_length;
	while (cursor < cursor_end)
	{
		for (size_t quantumPosition = 0; quantumPosition < 4; quantumPosition++)
		{
			temp <<= 6;
			if       (*cursor >= 0x41 && *cursor <= 0x5A) // This area will need tweaking if
				temp |= *cursor - 0x41;		              // you are using an alternate alphabet
			else if  (*cursor >= 0x61 && *cursor <= 0x7A)
				temp |= *cursor - 0x47;
			else if  (*cursor >= 0x30 && *cursor <= 0x39)
				temp |= *cursor + 0x04;
			else if  (*cursor == 0x2B)
				temp |= 0x3E; //change to 0x2D for URL alphabet
			else if  (*cursor == 0x2F)
				temp |= 0x3F; //change to 0x5F for URL alphabet
			else if  (*cursor == padCharacter) //pad
			{
				switch( cursor_end - cursor )
				{
				case 1: //One pad character
					*posdec++ = (temp >> 16) & 0x000000FF;
					*posdec++ = (temp >> 8 ) & 0x000000FF;
					return decodedBytes;
				case 2: //Two pad characters
					*posdec++ = (temp >> 10) & 0x000000FF;
					return decodedBytes;
				default:
					return NULL;
				}
			}  else
				return NULL;

			cursor++;
		}
		*posdec++ = (temp >> 16) & 0x000000FF;
		*posdec++ = (temp >> 8 ) & 0x000000FF;
		*posdec++ = (temp      ) & 0x000000FF;
	}
	return decodedBytes;
}