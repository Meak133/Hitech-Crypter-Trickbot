#ifndef _H_PROJECT_
#define _H_PROJECT_

#include <windows.h>

typedef unsigned __int64 QWORD;
typedef QWORD *PQWORD;

#pragma pack(push, 8)
typedef struct _BRUTE_THREAD_ARG
{
	WCHAR					wBaseDestFile[0x100];
	WCHAR					wDestFile[0x100];
	QWORD					qSeed;
	HANDLE					hThread;
	DWORD					dwThreadId;

	DWORD					dwCoreIndex;
	DWORD					dwNumOfCores;
	DWORD					dwNumOfSamplesPerCore;

	PQWORD					pSeedsQueue;
	DWORD					dwNumOfSeedsInQueue;
	DWORD					dwNumOfCleanTemplates;

} BRUTE_THREAD_ARG, *PBRUTE_THREAD_ARG;
#pragma pack(pop)

#endif