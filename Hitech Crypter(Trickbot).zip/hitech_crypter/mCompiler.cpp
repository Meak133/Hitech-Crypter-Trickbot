﻿#include "config.h"

#include <windows.h>
#include <tchar.h>
#include <intrin.h>
#include <Strsafe.h>

#include "globals.h"
#include "mCompiler.h"

mCompiler::mCompiler(mPathBuilder* path_builder, PVOID orig_file_data) : bat(1024)
{
	nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)orig_file_data + ((PIMAGE_DOS_HEADER)orig_file_data)->e_lfanew);

	this->path_builder = path_builder;
	is_resource = false;

	InitializeListHead(&lines);
	InitializeListHead(&files);
	InitializeListHead(&pause_lines);

	entry_point = NULL;
	advanced_flags = NULL;
}

void mCompiler::set_entry_point(PCHAR entry_point_name)
{
	entry_point = entry_point_name;
}

DWORD mCompiler::get_image_size(PCHAR file_path)
{
	HANDLE	h_file = CreateFileA(file_path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL, NULL);
	DWORD	image_size = -1;

	if (h_file != (HANDLE)-1)
	{
		BYTE  file_headers[0x1000];
		DWORD readed;

		if (ReadFile(h_file, file_headers, sizeof(file_headers), &readed, NULL))
		{
			PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)file_headers;
			if (dos->e_magic == IMAGE_DOS_SIGNATURE && dos->e_lfanew + sizeof(IMAGE_NT_HEADERS) < sizeof(file_headers))
			{
				PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((DWORD_PTR)dos + dos->e_lfanew);
				if (nt->Signature == IMAGE_NT_SIGNATURE)
				{
					if (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_I386)
					{
						image_size = ((PIMAGE_NT_HEADERS32)nt)->OptionalHeader.SizeOfImage;
					}
					else {
						image_size = ((PIMAGE_NT_HEADERS64)nt)->OptionalHeader.SizeOfImage;
					}
				}
			}
		}

		CloseHandle(h_file);
	}

	return image_size;
}


bool mCompiler::add_custom_line(PCHAR format, ...)
{
	PMCOMPILER_LINE new_line = (PMCOMPILER_LINE)halloc(sizeof(MCOMPILER_LINE));
	if (new_line)
	{
		va_list argptr;

		va_start(argptr, format);
		wvsprintfA(new_line->string, format, argptr);
		va_end(argptr);

		InsertTailList(&lines, &new_line->entry);

		return true;
	}

	return false;
}

void mCompiler::add_pause_line(PCHAR format, ...)
{
	PMCOMPILER_LINE_EX new_line = (PMCOMPILER_LINE_EX)halloc(sizeof(MCOMPILER_LINE));
	if (new_line)
	{
		new_line->string = (PCHAR)halloc(1025);
		if (new_line->string)
		{
			va_list argptr;

			va_start(argptr, format);
			wvsprintfA(new_line->string, format, argptr);
			va_end(argptr);

			InsertTailList(&pause_lines, &new_line->entry);
		}
	}
}

void mCompiler::add_pause_line_ex(PCHAR line)
{
	PMCOMPILER_LINE_EX new_line = (PMCOMPILER_LINE_EX)halloc(sizeof(MCOMPILER_LINE_EX));
	if (new_line)
	{
		new_line->string = (PCHAR)halloc(lstrlenA(line) + 1);
		if (new_line->string)
		{
			lstrcpyA(new_line->string, line);
		}

		InsertTailList(&pause_lines, &new_line->entry);
	}
}

void mCompiler::strip_extension(PCHAR dest, PCHAR source)
{
	if (dest && source)
	{
		DWORD length = lstrlenA(source);

		lstrcpyA(dest, source);
		if (length && dest[length - 4] == '.')
			dest[length - 4] = 0;
	}
}

bool mCompiler::add_custom_file(PCHAR format, ...)
{
	PMCOMPILER_LINE new_line = (PMCOMPILER_LINE)halloc(sizeof(MCOMPILER_LINE));
	if (new_line)
	{
		va_list argptr;

		va_start(argptr, format);
		wvsprintfA(new_line->string, format, argptr);
		va_end(argptr);

		InsertTailList(&files, &new_line->entry);

		return true;
	}
	return false;
}

void mCompiler::add_file(PCHAR file_name)
{
	add_custom_file("%s", file_name);
}

bool mCompiler::add_resource()
{
	if (add_custom_line("rc.exe \"%s\"", "resource.rc"))
	{
		return add_custom_file("resource.res");
	}
	return false;
}

bool mCompiler::add_main_cpp()
{
	return add_custom_file("main.cpp");
}

bool mCompiler::add_asm_file(PCHAR file_name)
{
	if (file_name)
	{
		CHAR name_no_ext[MAX_PATH];

		strip_extension(name_no_ext, file_name);

		if (add_custom_line("ml.exe /c /nologo \"%s\" \"%s.obj\"", file_name, name_no_ext))
		{
			return add_custom_file("%s.obj", name_no_ext);
		}
	}
	return false;
}

void mCompiler::set_advanced_flags(PCHAR flags)
{
	advanced_flags = flags;
}

void mCompiler::create_bat_file(PCHAR bat_path, PCHAR out_file)
{
	bat.clear();

	bat << "@echo off\r\n";

	PCHAR platform = (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_I386 ? "32" : "64");

	bat << "set vcvarsall=\"E:\\Visual Studio 2019\\VC\\Auxiliary\\Build\\" << "vcvars" << platform << ".bat\"\r\n";
	bat << "call %vcvarsall%\r\n";
	bat << "\r\n";

	PMCOMPILER_LINE line = (PMCOMPILER_LINE)lines.Flink;
	while (line != (PMCOMPILER_LINE)&lines)
	{
		bat << line->string << "\r\n";
		line = (PMCOMPILER_LINE)line->entry.Flink;
	}

	bat << "cl.exe";

	PMCOMPILER_LINE file = (PMCOMPILER_LINE)files.Flink;
	while (file != (PMCOMPILER_LINE)&files)
	{
		bat << " \"" << file->string << "\"";
		file = (PMCOMPILER_LINE)file->entry.Flink;
	}

	bat << " kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib version.lib "
		<< advanced_flags
		<< " /std:c++17 /nologo /GS- /MT /link /subsystem:windows";

	if (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_I386) {
		bat << " /MACHINE:X86";
	}
	else {
		bat << " /MACHINE:X64";
	}

	if (entry_point)
		bat << " /ENTRY:" << entry_point;

	bat << " /SAFESEH:NO /OUT:\"" << out_file << "\"";

	if (nt->FileHeader.Characteristics & IMAGE_FILE_DLL)
	{
		bat << " /DLL /DYNAMICBASE"; // /DYNAMICBASE and /NXCOMPAT prevent avira TR/Crypt.ZPACK.gen8 
	}
	else {
		// check for shellcode, all DataDirectories is empty
		INT si = 0;
		while (si < 15 && !nt->OptionalHeader.DataDirectory[si].VirtualAddress)
		{
			si++;
		}


		if (nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress || si >= 15)
		{
			bat << " /FIXED:NO /DYNAMICBASE"; // /DYNAMICBASE and /NXCOMPAT prevent avira TR/Crypt.ZPACK.gen8 
		}
		else {
			// was non commented 31.01.2015
			//bat << " /FIXED /BASE:" << nt->OptionalHeader.ImageBase;
			bat << " /FIXED";
		}
	}

	bat << " /NXCOMPAT"; // /DYNAMICBASE and /NXCOMPAT prevent avira TR/Crypt.ZPACK.gen8 

	if (random.get_less(0, 2) == 1) // áåç /RELEASE checksum==0 çà÷àñòóþ ñáèâàåò áèò äåòåêòû
		bat << " /RELEASE";

	if (is_resource)
		bat << " \"" << path_builder->get_tmp_folder() << "resource.res\"\r\n";

	bat << "\r\n";

	file_put_contentsA(bat_path, bat.get(), bat.length());

#ifdef _DEBUG

	PMCOMPILER_LINE_EX linex = (PMCOMPILER_LINE_EX)pause_lines.Flink;
	while (linex != (PMCOMPILER_LINE_EX)&pause_lines)
	{
		bat << linex->string << "\r\n";
		linex = (PMCOMPILER_LINE_EX)linex->entry.Flink;
	}

	bat << "pause\r\n";

	CHAR pause_path[MAX_PATH];

	lstrcpyA(pause_path, bat_path);
	lstrcatA(pause_path, "_pause.bat");

	file_put_contentsA(pause_path, bat.get(), bat.length());
#endif
}

DWORD mCompiler::build(PCHAR out_file)
{
	WCHAR out_file_w[MAX_PATH];
	INT i;

	for (i = 0; out_file[i]; i++)
	{
		out_file_w[i] = out_file[i];
	}
	out_file_w[i] = 0;

	return build(out_file_w);
}
LONG Filter(PEXCEPTION_POINTERS pep)
{
	// pep->ExceptionRecord->ExceptionCode
	// pep->ExceptionRecord->ExceptionAddress
	// GetModules();
	// GetCallStack();
	return EXCEPTION_CONTINUE_SEARCH;
}
DWORD mCompiler::build(PWCHAR out_file)
{
	// check tmp folder, all generated files will be stored where
	CHAR	bat_path[MAX_PATH];
	DWORD	image_size;

	lstrcpyA(bat_path, path_builder->get_tmp_folder());
	lstrcatA(bat_path, "build.bat");

	PMSTRA out_file_ascii = mCode::convert_ascii(out_file, -1);

	if (!out_file_ascii)
	{
		_tprintf(_T("Critical Error: ascii2unicode build fail!\r\n"));
		return -1;
	}

	create_bat_file(bat_path, out_file_ascii->string);

	DeleteFile(out_file);

	SHELLEXECUTEINFOA ShExecInfo = { 0 };

	ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	ShExecInfo.hwnd = NULL;
	ShExecInfo.lpVerb = NULL;
	ShExecInfo.lpFile = bat_path;
	ShExecInfo.lpParameters = NULL;
	ShExecInfo.lpDirectory = path_builder->get_tmp_folder();
	ShExecInfo.nShow = SW_HIDE;
	ShExecInfo.hInstApp = NULL;

	ShellExecuteExA(&ShExecInfo);
	WaitForSingleObject(ShExecInfo.hProcess, INFINITE);
	//MessageBox(0, 0, 0, 0);

	image_size = get_image_size(out_file_ascii->string);

	if (!file_exists(out_file_ascii->string))
	{
		_tprintf(_T("Critical Error: Can not build file, rebuild please or tell support!\r\n"));
		printf("Send to support:\r\nSeed: 0x%0.8X%0.8X\r\nFolder: %s\r\n", (DWORD)(random.get_seed() >> 32), (DWORD)random.get_seed(), path_builder->get_tmp_folder());
		return -1;
	}
	else {
		if (image_size == -1)
		{
			image_size = 0;
		}
	}

	hfree(out_file_ascii);

	return image_size;
}