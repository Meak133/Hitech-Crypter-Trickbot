#include <windows.h>
#include <tchar.h>

#include "config.h"
#include "mPathBuilder.h"
#include "funcs.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
//	path_GetBasicPathes
/////////////////////////////////////////////////////////////////////////////////////////////////
BOOL _stdcall path_GetBasicPathes(PAPP_BASIC_PATHES OUT pPathes)
{
	WCHAR	wtmpstr[0x100];
	DWORD	i, n;

	memset(pPathes, 0, sizeof(APP_BASIC_PATHES));
	GetModuleFileNameW(0, wtmpstr, _countof(wtmpstr));
	_wfullpath(pPathes->wExePath, wtmpstr, _countof(pPathes->wExePath));

	wcscpy(pPathes->wExeDir, pPathes->wExePath);
	i = wcslen(pPathes->wExeDir); while (pPathes->wExeDir[i] != L'\\') i--; pPathes->wExeDir[i] = 0;

	GetWindowsDirectoryW(pPathes->wWinDir, _countof(pPathes->wWinDir));
	GetSystemDirectoryW(pPathes->wSysDir, _countof(pPathes->wSysDir));
	n = GetTempPathW(_countof(pPathes->wTmpDir), pPathes->wTmpDir);
	pPathes->wTmpDir[n - 1] = 0;

	return TRUE;
};

mPathBuilder::mPathBuilder(DWORD pid, DWORD64 rand_name)
{
	this->pid = pid;
	this->rand_name = rand_name;

	*exe_folder = 0;
	*tmp_folder = 0;

	// get exe folder
	GetModuleFileNameA(NULL,exe_folder, MAX_PATH);

	// erase file name in path
	if( *exe_folder )
	{
		DWORD length = lstrlenA(exe_folder);
		for(int i = length - 1; i > 0; i--)
		{
			if( exe_folder[i]==_T('/') || exe_folder[i]==_T('\\') )
			{
				exe_folder[i + 1] = 0;
				break;
			}
		}
	}
}

BOOL mPathBuilder::create_tmp_folder()
{
	DWORD attr;

	lstrcpyA(tmp_folder, exe_folder);
	lstrcatA(tmp_folder, "tmp\\");

	attr = GetFileAttributesA(tmp_folder);
	if( attr==INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY) )
	{
		CreateDirectoryA(tmp_folder,NULL);

		attr = GetFileAttributesA(tmp_folder);
		if( attr==INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY) )
		{
			_tprintf(_T("Critical Error: Can not find/create tmp directory in %s\r\n"),tmp_folder);
			return FALSE;
		}
	}

	CHAR tmp_name[50];
	int rndname = 0; rndname = rand();
	// create temporary directory, because may be lauch many instances of crypt
	wsprintfA(tmp_name,"%d_%0.8X%0.8X\\", pid,(DWORD)(rand_name >> 32),(DWORD)rand_name);
	//wsprintfA(tmp_name, "%d_%0.8X%0.8X\\", pid, (DWORD)(rndname >> 32), (DWORD)rndname);
	lstrcatA(tmp_folder, tmp_name);

	CreateDirectoryA(tmp_folder,NULL);

	attr = GetFileAttributesA(tmp_folder);
	if( attr==INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY) )
	{
		_tprintf(_T("Critical Error: Can not find/create tmp directory in %s\r\n"),tmp_folder);
		return FALSE;
	}

	return TRUE;
}

void mPathBuilder::add_file(PCHAR file_name, PVOID data, DWORD data_size)
{
	CHAR	path[MAX_PATH];

	lstrcpyA(path, tmp_folder);
	lstrcatA(path, file_name);

	file_put_contentsA(path, data, data_size);
}

PMBUF mPathBuilder::get_file(PCHAR file_name)
{
	CHAR	path[MAX_PATH];

	lstrcpyA(path, tmp_folder);
	lstrcatA(path, file_name);

	return file_get_contentsA(path);
}

int mPathBuilder::remove_tmp_folder()
{
	int res = -1;

// #ifndef CONFIG_DEBUG_SOURCE
// 	SHFILEOPSTRUCTA sfo;
// 
// 	ZeroMemory(&sfo,sizeof(sfo));
// 
// 	tmp_folder[lstrlenA(tmp_folder) + 1] = 0;
// 
// 	sfo.pFrom  = tmp_folder;
// 	sfo.wFunc  = FO_DELETE;
// 	sfo.fFlags = FOF_NOCONFIRMATION | FOF_NOCONFIRMMKDIR | FOF_MULTIDESTFILES | FOF_SILENT;
// 
// 	 res = SHFileOperationA(&sfo);
// #endif

	return res;
}

PCHAR mPathBuilder::get_tmp_folder()
{
	return tmp_folder;
}

PCHAR mPathBuilder::get_exe_folder()
{
	return exe_folder;
}